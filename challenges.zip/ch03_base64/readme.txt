Challenge 03 - Base64
---------------------
Base64 is an encoding, NOT encryption. It turns data into letters,
digits, + and /. You can decode it with the `base64` command.

Decode encoded.txt and read the flag.
