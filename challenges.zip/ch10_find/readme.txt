Challenge 10 - The tree
-----------------------
The flag is buried somewhere inside level1/. There are many decoy files.
Do not open them one by one. Use `find` and `grep` to search the tree.

Hint: use `find` and `grep`.
