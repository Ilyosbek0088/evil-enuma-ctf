Another dead end.
