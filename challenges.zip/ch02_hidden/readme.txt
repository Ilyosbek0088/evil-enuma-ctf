Challenge 02 - Hidden in plain sight
------------------------------------
Sometimes the interesting file does not show up with a normal listing.
On Linux, files whose name starts with a dot (.) are "hidden".

Your flag is hiding in this directory. Find it.
