Challenge 06 - Never trust the extension
----------------------------------------
A filename ending in .jpg does not guarantee it is a real image.
Ask the system what the file really is.

Study photo.jpg and recover the flag.
