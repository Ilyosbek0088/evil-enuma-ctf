Challenge 08 - Logs tell stories
--------------------------------
Logs are gold. Attackers, mistakes and secrets all leave traces.
Search the web server log for something suspicious.

Hint: `grep` is your friend.
