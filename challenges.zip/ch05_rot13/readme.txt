Challenge 05 - ROT13
--------------------
ROT13 shifts every letter 13 places in the alphabet.
It is its own inverse: applying it twice gives back the original.

Decode rot13.txt to reveal the flag.
Hint: use `tr`.
