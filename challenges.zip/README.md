# localCTF - Beginner Challenge Set (10 Questions)

All challenges live in this folder. Difficulty: EASY.

## Flag format
`EVIL-ENUMA{...}`

## Rules
- Each challenge has its own folder with a `readme.txt`.
- Read the readme, inspect the files, recover the flag.
- No internet needed. Everything is local.

## Challenges
| # | Folder | Topic |
|---|--------|-------|
| 01 | ch01_welcome | Sanity / reading files |
| 02 | ch02_hidden | Hidden dotfiles |
| 03 | ch03_base64 | Base64 decoding |
| 04 | ch04_hex | Hexadecimal decoding |
| 05 | ch05_rot13 | ROT13 cipher |
| 06 | ch06_filetype | File identification |
| 07 | ch07_strings | `strings` on binaries |
| 08 | ch08_logs | Searching logs with grep |
| 09 | ch09_reverse | Reversing text |
| 10 | ch10_find | Finding files in a tree |

Good luck!
