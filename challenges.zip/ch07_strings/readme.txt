Challenge 07 - Strings
----------------------
Binary files contain lots of non-printable junk. The `strings` command
pulls out the readable text, which is often enough to find secrets.

Find the flag inside data.bin.
