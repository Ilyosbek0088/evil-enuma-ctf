Challenge 04 - Hexadecimal
--------------------------
Computers love hex. Hex uses 0-9 and a-f.
The file hex.txt holds the flag as hexadecimal bytes.

Hint: `xxd -r -p hex.txt`
