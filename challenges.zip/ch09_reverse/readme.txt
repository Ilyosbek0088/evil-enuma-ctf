Challenge 09 - Backwards
------------------------
The text in backwards.txt is written in reverse.
Read it normally and you will see garbage. Flip it around.

Hint: the `rev` command reverses lines.
